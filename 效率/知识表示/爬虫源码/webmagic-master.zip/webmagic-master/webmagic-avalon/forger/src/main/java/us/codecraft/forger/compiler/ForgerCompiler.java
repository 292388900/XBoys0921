package us.codecraft.forger.compiler;

/**
 * @author code4crafter@gmail.com
 */
public interface ForgerCompiler {

    public Class compile(String sourceCode);
}
